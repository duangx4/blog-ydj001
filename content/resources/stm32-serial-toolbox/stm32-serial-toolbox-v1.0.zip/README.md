# STM32 串口工具箱 v1.0

## 这是什么
一个命令行小工具：把 STM32 板子上的串口日志按时间戳分段、过滤噪声行、导出成干净文本。

## 用法
    python3 serial-tidy.py <串口日志.txt> --drop-noise --split 30s

## 依赖
Python 3.9+，只用标准库。
