#!/usr/bin/env python3
"""把串口日志按噪声行过滤并按时间间隔分段。用法: serial-tidy.py <日志> [--drop-noise] [--split 30s]"""
import re, sys
NOISE = re.compile(r"^\s*(?:\[?\d*\]?\s*)?(?:WARN|DEBUG|heartbeat|tick)\b", re.I)
TS = re.compile(r"^\[?(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))?\]?")
def main(argv):
    src, drop, split = argv[1], "--drop-noise" in argv, 30
    for a in argv:
        if a.startswith("--split"): split = int(re.sub(r"\D", "", a) or 30)
    seg = 0; last = None; out = open(f"clean-{seg:03d}.txt", "w")
    for line in open(src, encoding="utf-8", errors="replace"):
        if drop and NOISE.match(line): continue
        m = TS.match(line.strip())
        if m:
            sec = int(m.group(1))*3600 + int(m.group(2))*60 + int(m.group(3))
            if last is not None and sec - last > split:
                out.close(); seg += 1; out = open(f"clean-{seg:03d}.txt", "w")
            last = sec
        out.write(line)
    out.close(); print(f"输出 {seg+1} 个分段文件")
if __name__ == "__main__": main(sys.argv)
